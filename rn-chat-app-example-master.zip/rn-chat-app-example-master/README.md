# Example Chat App
 Go to the directory where the file is located then install npm
 
 
### React Native Run 
 
 ```bash
 cd ChatApp && npm install
 react-native run-android
 react-native run-ios
 ```


### Server Run 
 
 ```bash
 cd sockerServer && npm install
 node index.js
 ```

